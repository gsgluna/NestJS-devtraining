import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { customersModule } from './customers/customers.module';

@Module({
  imports: [customersModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
