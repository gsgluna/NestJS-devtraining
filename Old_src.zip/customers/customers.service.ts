import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { Customer } from './entities/customer.entity';

@Injectable()
export class customersService {
    private customers: Customer[] = [
        {
            id: 1,
            name: "Samuel",
            address: "Arraial Street, 3574, Yellow House",
            sex: "M",
            age: 48,
            city: "Recife",
            country: "Brazil"
            
        },
    ];

    findAll(){
        return this.customers;        
    }

    findOne(id: string){
        const costumer =  this.customers.find((Customer: Customer) => Customer.id == Number(id));        

        if (!costumer) {

          throw new HttpException(`Costumer ID ${id} not found`, HttpStatus.NOT_FOUND) 


        }
    }

    create(createCustomerDto: any){
        this.customers.push(createCustomerDto);
    }

    update(id: string, updateCustomerDto: any) {
        const indexCustomer = this.customers.findIndex(
          (customer) => customer.id === Number(id),
        );
    
        this.customers[indexCustomer] = updateCustomerDto;
      }
    
      remove(id: string) {
        const indexCustomer = this.customers.findIndex(
          (customer) => customer.id === Number(id),
        );
    
        if (indexCustomer >= 0) {
          this.customers.splice(indexCustomer, 1);
        }
      }



}
