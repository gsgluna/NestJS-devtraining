export class UptadeCustomerDto {
    readonly name?: string;
    readonly address?: string;
    readonly sex?: string;
    readonly age?: number;
    readonly city?: string;
    readonly country?: string
}
